## Discourse Follow

This Discourse plugin allows you to follow other users, list the latest topics involving them and receive notifications when they post.

Installation guide, plugin documentation, screenshots and more details can be found in the [plugin's topic](https://meta.discourse.org/t/follow-plugin/110579?u=osama) on Discourse Meta. Please submit bug reports and feature requests over there as well.

This plugin is an official plugin maintained by the Discourse team (CDCK, Inc).

### Credits

This plugin was originally developed by [Pavilion](https://thepavilion.io) and maintained by them until October 2021 when maintenance was transferred to the Discourse team.
