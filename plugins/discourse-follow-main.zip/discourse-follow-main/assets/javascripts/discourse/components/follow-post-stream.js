import UserStream from "discourse/components/user-stream";

export default class FollowPostStream extends UserStream {}
